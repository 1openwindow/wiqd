#Requires -Version 7.0
[CmdletBinding(DefaultParameterSetName = 'Check')]
param(
    [Parameter(ParameterSetName = 'Check')][switch]$Check,
    [Parameter(Mandatory, ParameterSetName = 'Prepare')][switch]$Prepare,
    [Parameter(Mandatory, ParameterSetName = 'Restore')][switch]$Restore,
    [string]$MarketplacePath,
    [string]$WiqdPath,
    [string]$CopilotPath,
    [Parameter(ParameterSetName = 'Prepare')]
    [Parameter(ParameterSetName = 'Restore')]
    [switch]$ConfirmChanges,
    [switch]$Json
)

$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$helper = Join-Path $PSScriptRoot 'lib/validation-bugbash.mjs'
$originalConsoleEncoding = [Console]::OutputEncoding
$originalOutputEncoding = $OutputEncoding
$result = 2
try {
    # Node emits UTF-8 even when a Windows terminal inherited a legacy code page.
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    $OutputEncoding = [Console]::OutputEncoding
    $node = (Get-Command node -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
    $mode = if ($Prepare) { 'prepare' } elseif ($Restore) { 'restore' } else { 'check' }
    $arguments = @($helper, '--mode', $mode)
    foreach ($tool in @('wiqd', 'copilot')) {
        $command = Get-Command $tool -CommandType Application, ExternalScript -ErrorAction SilentlyContinue |
            Select-Object -First 1
        $pathSelected = if ($command) { $command.Source } else { '' }
        $explicit = if ($tool -eq 'wiqd') { $WiqdPath } else { $CopilotPath }
        if ($explicit) {
            $selected = (Get-Item -LiteralPath $explicit -ErrorAction Stop).FullName
        } else {
            $selected = $pathSelected
        }
        $arguments += @("--$tool", $selected)
        if ($tool -eq 'wiqd') { $arguments += @('--path-wiqd', $pathSelected) }
    }
    if ($MarketplacePath) { $arguments += @('--marketplace', $MarketplacePath) }
    elseif (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'bugbash-manifest.json')) {
        $arguments += @('--marketplace', $PSScriptRoot)
    }
    if ($ConfirmChanges) { $arguments += '--confirm-changes' }
    if ($Json) { $arguments += '--json' }
    & $node @arguments
    $result = $LASTEXITCODE
} catch {
    if ($Json) {
        @{ status = 'FAILED'; message = $_.Exception.Message; next = 'Check the selected executable paths and Node.js installation.' } |
            ConvertTo-Json -Compress | Write-Output
    } else {
        [Console]::Error.WriteLine("Bugbash preparation failed: $($_.Exception.Message)")
    }
    $result = 2
} finally {
    [Console]::OutputEncoding = $originalConsoleEncoding
    $OutputEncoding = $originalOutputEncoding
}
exit $result
