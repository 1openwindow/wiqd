# Prepare Validate Next in GitHub Copilot CLI

Prepare the installed CLI and plugin; do not start validation, repair or publishing.
This procedure supports **GitHub Copilot CLI**, not VS Code or other Copilot hosts.
It requires PowerShell 7+, Node 24.15.0+ and an already compatible WIQD on PATH.
Missing CLI capability is a separate installation task, not permission to upgrade here.

## 1. Check the installed WIQD

Use the organizer's fixed ZIP and independent SHA-256. Verify the archive before extracting or
executing it; reject unsafe paths/links and extract all files into a new persistent directory.
Do not overwrite an existing directory or accept a changed hash. For an unverified local directory,
request the trusted ZIP instead. Once the ZIP is verified, the helper checks its complete inventory;
do not recreate the tree-hash algorithm. Keep notes outside the candidate.

From the complete extracted directory:

```powershell
pwsh -NoProfile -File ./prepare-validation-bugbash.ps1 -Check -Json
```

Read the exit code and JSON. `SETUP_REQUIRED` is expected before installation: its `plan` lists
the changes to make. `BLOCKED` means stop and report the reason. Missing/incompatible WIQD needs
the organizer-approved CLI installation separately. Never replace the CLI, build source, change
PATH/registries or install prerequisites here. Do not probe broker/login, TDP or models at setup.

## 2. Confirm once, install and switch

Show `plan` and ask **one confirmation** covering the flag and plugin changes. After approval:

```powershell
pwsh -NoProfile -File ./prepare-validation-bugbash.ps1 -Prepare -ConfirmChanges -Json
```

The helper records the original plugin and flag state, enables `validation-next` if necessary,
installs the preview and disables other enabled user WIQD plugins. It preserves old sources,
already-disabled plugins and unrelated plugins. Do not edit individual workflows or deactivate
the legacy validation extension used by plugin validation/LSP. A false environment override,
ambiguous source or managed/project conflict must be reconciled, not bypassed.

`-ConfirmChanges` relays the user's approval; it does not create it. Do not accept EULAs or sign
in for the user. On failure, report actual/uncertain changes and keep the journal; do not retry
blindly, delete plugins, rebind marketplaces or edit settings/journals by hand.

## 3. Restart once and finish

For `PREPARED_RESTART_REQUIRED`, ask the user to open a **new Copilot CLI session**. Give one
continuation containing the extracted directory and the same `-Check -Json` command. Do not run
slash commands in a shell, kill Node processes or launch a nested Copilot to continue the task.

After restart, `READY` means the configured preview source is verified, it is the only enabled
WIQD plugin, and the effective flag is true. Say **“Validate Next is ready to try.”** Give one
example: “Please check this agent project for Marketplace submission: <PROJECT_PATH>. Do not
deploy or publish.” Installation readiness does not mean live validation passed.

Keep the response short: result, next action and recovery record location. Detailed identity,
operations and original states are in JSON and `~/.wiqd/bugbash/validation-next/state.json`;
do not require the tester to write another technical handover.

## Optional: restore the previous plugin

After showing the recorded restoration plan and obtaining confirmation:

```powershell
pwsh -NoProfile -File ./prepare-validation-bugbash.ps1 -Restore -ConfirmChanges -Json
```

Open a new CLI session afterward. Restore recovers recorded plugin enabled states, not the CLI
or flag. It works without a healthy WIQD; keep the helper bundle and journal available. A changed
identity/state or unknown mutation requires reconciliation. The recorded flag observation is for
a separately requested ordinary CLI operation, never an inferred reset or whole-config rewrite.
