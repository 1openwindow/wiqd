# WIQD Validation — bug bash guide

Use **GitHub Copilot** to try the new agent validation experience: check a source project or
ZIP, read its report, and optionally fix the reported issues and check again. You do not need to
clone or build WIQD. Your installed WIQD may be a different version; preparation checks the actual
capabilities and asks before any required upgrade.

This is a preview for testing, not permission to deploy, publish or submit to Marketplace. Use a
disposable agent project and approved test accounts/artifacts. Keep a copy of your original inputs.

## 1. Prepare your environment

Open a GitHub Copilot conversation. Copy the complete preparation prompt below and follow
its questions. It identifies the fixed plugin download and approved CLI source; you should not
have to find versions or fill package hashes yourself. If the complete prompt is missing, ask the
organizer for the published guide rather than using a random source ZIP or a moving latest build.

<!-- PREPARATION_PROMPT -->

Copilot checks first, explains the exact changes and asks for your approval. If needed, it offers
the approved CLI upgrade before switching plugins. During testing, the normal WIQD plugin is
disabled and the validation plugin alone is enabled. Your previous plugin state is retained for
recovery. You complete any login or EULA acceptance yourself.

Keep the preparation handover: candidate identity/location, WIQD and Copilot versions, plugin/flag
changes, any remaining blockers, and recovery instructions. If preparation reports a blocker,
send that result to the organizer; do not bypass checks or change settings by guesswork.

## 2. Reload Copilot

Use the reload/restart operation supported by your current GitHub Copilot environment, following
the preparation handover. Give the reloaded session that handover and ask it to finish the readiness
check and confirm the effective plugin source. Do not begin testing while readiness is blocked.
An installed plugin or a model saying it loaded is not by itself proof of a successful reload.

## Test prompts

Give Copilot one normal goal at a time, in your preferred language. Replace only your own project,
environment or ZIP path below; do not tell Copilot which commands or workflow files to use.

### Source project and Marketplace

```text
Please check this agent project for Marketplace submission: <PROJECT_PATH>.
Use the <BUILD_ENVIRONMENT> environment. You may create a local package, but do not deploy or publish.
```

Observe whether it checks the current source, asks for missing information, and gives you a report.
You should not need to create listing JSON or select an old build yourself.

### Changed source with a previous build still present

Make a real instruction change in your disposable project, leaving its previous ZIP in place:

```text
I have changed the agent instructions. Please check the project again for Marketplace submission.
```

Observe whether it checks the changed source rather than silently validating the previous build.

### Exact ZIP

```text
Please check this ZIP for Marketplace submission: <EXACT_ZIP_PATH>.
Do not change my source or the ZIP.
```

Observe whether it preserves your exact input and avoids unwanted source edits or rebuilding.

### Report continuation

After a report with an actionable finding, choose its repair option or ask:

```text
Fix the issues you just reported and check again. Do not deploy or publish anything.
```

Observe whether it keeps the report context, obtains any missing authorization/context, and gives
you a new result after repair. Also try declining repair or asking for a report only: your source
should remain unchanged. Missing inputs, permissions or vision should be reported, not called PASS.

## Send feedback

Reply to the organizer with:

- Candidate/CLI/Copilot identity from the handover, OS and whether you reloaded.
- Your task and initial state: source or ZIP, old build present, listing present/missing/invalid.
- Expected behavior versus actual questions/actions, report path/result and sanitized errors.
- Whether it reproduces, any blockers and whether recovery worked.

Keep original reports and notes outside the downloaded candidate directory. Do not upload customer
packages, listings, screenshots, tokens or personal information without separate approval.

## Restore your normal plugin

Keep the downloaded bundle and preparation handover. Paste this into Copilot with that handover:

```text
Restore my previous WIQD plugin state using my bug bash preparation handover and its fixed
preparation instruction. Inspect the recovery record, show the plan and ask before changing anything.
Do not guess my old settings, overwrite intervening changes, uninstall the CLI or accept terms.
```

After restoration, reload Copilot again. Restoration recovers recorded plugin enabled states;
it does not automatically downgrade the CLI or reset feature flags. Ask separately if you want a
flag restored, using its recorded baseline. If recovery reports a conflict, keep the record and
contact the organizer instead of deleting plugins or forcing old settings.
