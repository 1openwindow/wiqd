# WIQD Validation — bug bash guide

Use **GitHub Copilot CLI** to try the new agent validation experience: check a source project or
ZIP, read its report, and optionally fix the reported issues and check again. You do not need to
clone or build WIQD. Preparation checks that your installed WIQD includes Validate Next. If not,
ask the organizer for the compatible CLI installation before continuing.

This is a preview for testing, not permission to deploy, publish or submit to Marketplace. Use a
disposable agent project and approved test accounts/artifacts. Keep a copy of your original inputs.

## 1. Prepare your environment

Open a GitHub Copilot CLI conversation and paste the complete prompt below. Copilot checks WIQD,
shows one flag/plugin change plan and asks for one confirmation, then installs and switches the
workflow. You do not need to find versions, fill hashes or prepare a technical handover.

<!-- PREPARATION_PROMPT -->

Your old WIQD plugin remains installed but disabled during testing. The helper retains its state
for recovery and does not upgrade WIQD. If preparation is blocked, send the reason to the organizer.
Complete any login or EULA acceptance yourself when validation needs it.

## 2. Reload Copilot

If requested, open a **new Copilot CLI session** and paste the single continuation instruction
Copilot gave you. It rechecks configuration and tells you **“Validate Next is ready to try.”**
Then start testing. Setup success is not a validation PASS.

## Test prompts

Give Copilot one normal goal at a time, in your preferred language. Replace only your own project,
environment or ZIP path below; do not tell Copilot which commands or workflow files to use.

### Source project and Marketplace

```text
Please check this agent project for Marketplace submission: <PROJECT_PATH>.
Use the <BUILD_ENVIRONMENT> environment. You may create a local package, but do not deploy or publish.
```

Observe whether it checks the current source, asks for missing information, and gives you a report.
You should not need to create listing JSON or select an old build yourself.

### Changed source with a previous build still present

Make a real instruction change in your disposable project, leaving its previous ZIP in place:

```text
I have changed the agent instructions. Please check the project again for Marketplace submission.
```

Observe whether it checks the changed source rather than silently validating the previous build.

### Exact ZIP

```text
Please check this ZIP for Marketplace submission: <EXACT_ZIP_PATH>.
Do not change my source or the ZIP.
```

Observe whether it preserves your exact input and avoids unwanted source edits or rebuilding.

### Report continuation

After a report with an actionable finding, choose its repair option or ask:

```text
Fix the issues you just reported and check again. Do not deploy or publish anything.
```

Observe whether it keeps the report context, obtains any missing authorization/context, and gives
you a new result after repair. Also try declining repair or asking for a report only: your source
should remain unchanged. Missing inputs, permissions or vision should be reported, not called PASS.

## Send feedback

Reply to the organizer with:

- Preparation result/identity from the helper output, OS and whether you restarted.
- Your task and initial state: source or ZIP, old build present, listing present/missing/invalid.
- Expected behavior versus actual questions/actions, report path/result and sanitized errors.
- Whether it reproduces, any blockers and whether recovery worked.

Keep original reports and notes outside the downloaded candidate directory. Do not upload customer
packages, listings, screenshots, tokens or personal information without separate approval.

## Restore your normal plugin

Keep the downloaded bundle and its recovery record. Paste this into Copilot:

```text
Restore my previous WIQD plugin state using the preparation bundle and its recovery record.
Show the recorded plugin changes and ask before applying them. Do not reset my CLI or feature flag.
```

After restoration, open a new Copilot CLI session. Restoration recovers recorded plugin enabled states;
it does not automatically downgrade the CLI or reset feature flags. Ask separately if you want a
flag restored, using its recorded baseline. If recovery reports a conflict, keep the record and
contact the organizer instead of deleting plugins or forcing old settings.
