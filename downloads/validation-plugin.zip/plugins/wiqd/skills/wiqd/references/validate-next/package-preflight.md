# Source package preflight for validation

This is a package-command substep owned by the preview validation/collection/repair caller,
not a standalone Package workflow. Return the exact created ZIP to that caller; do not dispatch
validation here. Preserve its modes, listing, source project, confirmed environment and consent.

Require a confirmed existing declarative-agent source project and build environment. Detect
`m365agents.yml`, `m365agents.local.yml`, `teamsapp.yml` and `teamsapp.local.yml` case-insensitively
but require canonical lowercase spelling. Missing/ambiguous context asks only for that context;
do not scaffold, assume `prod`, provision or infer a source project from a ZIP-only folder.

Inspect `appPackage/manifest.json` and its declared declarative-agent files, not an assumed
`declarativeAgent.json`. Keep WIQD's packaging preflight intact: missing/unsafe references,
unsupported local Worker references or generated/TypeSpec manifest selection remain blockers.
Skill-folder packaging and environment requirements are enforced by the installed command;
report its actionable diagnostics rather than inventing a bypass or changing flags automatically.

Explain the local ZIP write and obtain authorization unless the user already requested this
build or report-bound repair. Choose a new absolute output path that does not exist, then call
`wiqd agent package` directly with explicit source, environment and output as documented by the
caller. Require exit 0, a non-empty ZIP and `data.outputPath` matching the exact requested target.
Failure or mismatch stops without selecting newest or reusing a stale ZIP. Preserve original
packages, reports and supplied listing/evidence. Do not manually assemble archives, follow
deployment suggestions or treat local packaging as publication/certification.
