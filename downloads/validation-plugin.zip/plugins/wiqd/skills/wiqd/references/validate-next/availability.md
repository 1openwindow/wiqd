# Validation workflow availability

Before input access and each source mutation/package/helper/validation batch, run:

```bash
wiqd config flags show validation-next --json --skill wiqd --workflow validation-next
```

Require exit 0, `status: success`, `data.name: validation-next` and `data.value === true`.
Inspect the effective source, including environment overrides; do not reuse a previous turn's
enabled state. False, unknown, unavailable or failed checks stop this preview before side effects.
Explain that the user must explicitly enable the PR1 flag or restore the normal plugin to use
the old workflow. Never change config, install/register extensions or fall back automatically.

At workflow entry and after a CLI change, also verify:

```bash
wiqd agent validate --help --skill wiqd --workflow validation-next
```

Require new Manifest/Marketplace modes and `--listing-file` capability. A version string alone
is not proof that the installed CLI contains PR1. Missing capability is an explicit upgrade
prerequisite, not permission to install/repair it or claim file-only validation. The installed
CLI and this preview remain separate; this preview does not retire any flag or legacy command.
