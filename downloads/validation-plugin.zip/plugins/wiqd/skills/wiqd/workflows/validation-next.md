---
name: validation-next
description: Validate agent source through a fresh package or an explicit final ZIP, with Manifest/Marketplace checks and authorized report-bound repair.
trigger-summary: 'validate my agent, validate package, validate this ZIP, Marketplace checks, repair this validation report'
triggers: 'validate package, validate this package, validate this ZIP, check this ZIP, validate package for marketplace, validate package manifest and marketplace, interpret my validation-next report, partner center validation, partner center validate, marketplace validation, marketplace validate, validate for partner center, validate for marketplace, fix validation-next findings, fix this validation-next report, validate and fix this package'
routing-label: 'Package validation and report-bound repair'
routing-intent: 'Validate agents, final ZIPs and Marketplace policy evidence; continue repairs of an identified report through fresh package and same-scope validation'
routing-order: 10
contract-version: 1
routing-requires: [agent validate]
---

# Package validation

This workflow belongs to the Validation Next extension. Its standalone plugin artifact selects
only this extension's content. Disable the normal WIQD plugin while testing that artifact;
the CLI flag does not select plugin content. Require validation-next enabled and never substitute
the legacy workflow here. Stable plugin profiles and other callers are unchanged by this delivery.
Use plain language with the customer; keep internal schema/evidence mechanics out of normal replies.

## 1. First action: check availability

Before input access, follow [availability](../references/validate-next/availability.md). Require the
effective flag to be true and the new command capability. False, unknown, unavailable or failed
checks stop; they do not route to an old workflow. Do not change flags, install/upgrade the CLI or
interpret a validation request as EULA/enablement consent. Recheck availability before each
helper/validation command and repair edit batch. Reload after plugin changes.

## 2. Select scope and inputs

**Repair continuation:** If the user asks to fix an identified validation report, including
“fix it”, “fix the issues” or equivalent requests in the user's language after this workflow's report, read
[autofix](../references/validate-next/autofix.md) now. Retain this workflow as owner until revalidation or a
concrete blocker; do not restart generic validation or hand the entire task to general editing.
If several reports could be meant, ask which. For “validate and fix”, first complete steps 2–4,
then continue to autofix without asking for the same authorization again.

| Request                                 | Mode                   |
| --------------------------------------- | ---------------------- |
| Validate a package/ZIP or manifest      | `manifest`             |
| Partner Center / Marketplace validation | `marketplace`          |
| Both package and Marketplace validation | `manifest,marketplace` |

Say which scope will run. Do not add Marketplace merely because a ZIP exists. Manifest uploads ZIP bytes to TDP and may request sign-in;
it is not an offline local MVL check. Missing auth/EULA or headless interactive failures are blockers,
not warnings that imply validation passed. Follow the orchestrator's human-consent EULA guidance.
Use the supplied final ZIP or CLI discovery under `appPackage/build`; ask if selection is unclear.

**Explicit ZIP:** preserve the user's exact ZIP without fallback, rebuilding or archive edits.
**Source request:** confirm the source project and build environment. Follow the existing-project
lifecycle and bundled-reference preflight in [package preflight](../references/validate-next/package-preflight.md).
Explain that validation needs a fresh local ZIP and ask for that write authorization unless the user
already requested packaging/rebuilding. Decline leaves files unchanged. Once authorized, call the
package command directly with explicit project/environment and a new absolute output path, then
validate that exact returned ZIP. Do not call the Package workflow recursively or validate first.
Never reuse an old ZIP, choose newest, guess an environment or automatically deploy. Failed packaging
stops before validation; missing source/build context asks only for the missing context.

Recheck availability, run the authorized source package command separately and inspect its result:

```bash
wiqd agent package --path "<project>" --env "<build-env>" --output "<new-absolute.zip>" --json --skill wiqd --workflow validation-next
```

Require the requested new output to exist and the returned package identity/path to agree. Otherwise
stop, rather than using an older build or guessing another path. This is not deployment authorization.

### Marketplace listing

Manifest-only skips collection. For Marketplace or both, ask the CLI to read the listing
from `<collection-workspace>/.validate/listing.json` using the command below. The collection workspace is
the known agent project, or the supplied ZIP's directory/ZIP-only folder.

```bash
wiqd agent validate get-market-listing --agent-folder "<collection-workspace>" --json --skill wiqd
```

Include `--listing-file "<supplied-listing.json>"` when explicitly provided.

- **Command succeeded:** skip collection and use the returned `data.listingPath` and listing unchanged.
- **Error code `"404"` or `MARKET_LISTING_INVALID`:** follow
  [listing collection](../references/validate-next/listing-collection.md) to collect and save a replacement
  with `add-market-listing`. Pass this workflow's exact selected ZIP and confirmed source/environment
  context; do not package again merely because the listing is missing. Resume this phase with the
  returned listing path and selected ZIP. An authorized source correction may return a new ZIP;
  use that exact replacement for subsequent evidence/validation without restarting this workflow.

The command checks the schema; do not judge validity yourself or inspect the schema.
Other CLI errors are blockers, not permission to replace a file.
The writer saves to the default workspace path; an invalid external listing remains untouched.
The CLI owns schema checks and JSON construction. Do not copy schemas into the skill.
Pass the selected absolute path as `--listing-file`. Partner Center account/offer setup
is not required for validation.

## 3. Run validation

For Manifest only:

```bash
wiqd agent validate --mode manifest --package-file "<final.zip>" --json --skill wiqd --workflow validation-next
```

For Marketplace or both, follow [current-agent evidence](../references/validate-next/current-agent-evidence.md)
to prepare evidence in this session and run validation as a host-managed background job.
Use the same ZIP and listing for preparation and validation.
Keep the host job handle, report running honestly, and retrieve that same job's output on completion;
do not start a duplicate run to check status. Let the CLI report execution errors.

## 4. Show the result

Read `data` or completed non-pass `error.data`. Use `validation.result` for the overall result,
not the exit code or policy-only `report.result`. Show required fixes, incomplete checks,
`validation.outputDir` and a clickable Markdown link to the returned `validation.reportPaths.html`.
Use `[Open HTML report](file:///...)` with a standard URL-encoded file URI as the target.
Do not show only a bare path/URI or wrap the link in code formatting.
Completed FAILED/ERROR runs can still have saved reports; do not guess paths after execution failure.
The output directory also retains the evaluated ZIP and supplied listing.

Keep the explanation short; the HTML report contains the details. Do not rewrite results or
present partial validation as official Marketplace approval.
This workflow validates only; it does not change publishing workflows.

Recommend the next step: fix validation findings or incomplete checks after FAILED/ERROR;
after PASSED, continue to the existing publishing workflow with its prerequisites unchanged.
A recommendation alone does not authorize edits or publishing.

## 5. Collect the repair decision

For actionable findings, this decision is part of completing the validation workflow. Show the
result and report link in a progress message, then invoke the native choice tool before ending the
turn. A final findings-only answer skips this step. Use the user's language.
If the user explicitly requested a report-only response or no questions, respect that scope and
finish with the findings instead of opening a choice prompt.

- **Actionable repair:** For a grounded Manifest error or failed Marketplace MF finding (or an
  explicitly selected warning/SF), call the host's native choice tool — **`ask_user` in Copilot** —
  with two choices: **“Fix and revalidate”** and **“Not now”**, localized to the user's language.
  Name the repairable finding in the question and explain source edit → new ZIP → same-mode
  revalidation. For example: “Fix `<finding>` in the source, build a new ZIP and revalidate with
  the same modes?” Adapt the finding and modes to the actual report; do not promise that all checks
  will pass.

  Invoke `ask_user` with this shape, adapting the question and localizing its text:

  ```json
  {
    "question": "Fix the reported source issue, build a new ZIP and revalidate with the same modes?",
    "choices": ["Fix and revalidate", "Not now"]
  }
  ```

  - An affirmative selection is repair authorization: continue to step 6 immediately, retaining
    this report/project/environment. Do not ask the user to type the choice or confirm again.
  - “Not now”, dismissal or cancellation: finish with the report available and files unchanged.
    Do not start repairs, choose on the user's behalf or repeatedly ask.
  - If the source project or build environment is unknown, disclose that prerequisite in the
    question; after an affirmative selection ask only for the missing context before editing.
  - Only if the tool is unavailable or interaction is disabled, and the user's requested response scope permits it,
    end with a localized text fallback: “Reply ‘Fix and revalidate’ to continue.”
    This fallback does not authorize repair. Do not imitate an interactive selector
    with Markdown checkboxes, invoke `Read-Host` or start another CLI to collect the choice.

- **No selected repair work or only blockers:** Give the applicable next action or missing input
  (such as service access, listing or screenshots), without promising automatic source repair.
- **Repair already authorized:** Continue to step 6 rather than asking for the same permission again.

Source edits, packaging and revalidation require an explicit repair request or affirmative choice.

## 6. Fix only when authorized

Retain the result, returned report paths, normalized modes, absolute ZIP path/hash, supplied listing
and any confirmed source-project/build-environment context for a follow-up. Validation alone does
not authorize source edits; use step 5's native choice when repair is actionable.

When repair is authorized, read [autofix](../references/validate-next/autofix.md) and execute its entire loop:
scoped source edits → explicit new ZIP → fresh evidence when selected → `agent validate` with the
original modes → verified progress and remaining findings. `validation-next` owns that loop.
